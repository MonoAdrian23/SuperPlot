<?php

namespace MonoAdrian23\SuperPlot\forms;

use MonoAdrian23\SuperPlot\Main;
use jojoe77777\FormAPI\SimpleForm;
use pocketmine\Player;
use pocketmine\item\Item;
use pocketmine\command\Command;

class PAPCForm extends SimpleForm {

    public function __construct() {

        $callable = function (Player $player, $data) {

            if ($data == null) return;

            if ($data == 0) {

                $player->sendMessage("Du hast das Menü verlassen");


            }
            if ($data == 1) {

                $player->getServer()->getCommandMap()->dispatch($player, "p auto");

            }

            if ($data == 2) {

                $player->getServer()->getCommandMap()->dispatch($player, "p claim");

            }
           
            if ($data == 3) {

                $player->getServer()->getCommandMap()->dispatch($player, "p home");  
            }

        };

        parent::__construct($callable);

        $this->setTitle("§l§dSuperPlot");

        $this->addButton("§3Verlasse das Menü");

        $this->addButton("§3Finde ein freies Plot");

        $this->addButton("§3Beanspruche ein freies Plot");

         $this->addButton("§3Plot Home");


    }

}
